<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.dashboard','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('dashboard'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>


            


            <?php if($message = Session::get('success')): ?>
            <div class="alert alert-success">
                <p><?php echo e($message); ?></p>
            </div>
        <?php endif; ?>

        <section class="content-header">
            <div class="container-fluid">
            <div class="row mb-2">
            <div class="col-sm-6">
            <h1>All Products</h1>
            </div>
            <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
            <li class="breadcrumb-item"><a href="#">Home</a></li>
            <li class="breadcrumb-item active">All Products</li>
            </ol>
            </div>
            </div>
            </div>
            </section>



            <section style="background-color: #eee;">
                <div class="container py-5">
                  <div class="row justify-content-center mb-3">

                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <div class="col-md-12 col-xl-10">
                        <div class="card shadow-0 border rounded-3">
                            <div class="card-body">
                            <div class="row">
                                <div class="col-md-12 col-lg-3 col-xl-3 mb-4 mb-lg-0">
                                <div class="bg-image hover-zoom ripple rounded ripple-surface">
                                    <?php
                                        $images = explode(",", $p->pimg)
                                    ?>
                                    <img src="<?php echo e(asset('uploads/'.$images[0])); ?>" class="w-100" />
                                    <a href="#!">
                                    <div class="hover-overlay">
                                        <div class="mask" style="background-color: rgba(253, 253, 253, 0.15);"></div>
                                    </div>
                                    </a>
                                </div>
                                </div>
                                <div class="col-md-6 col-lg-6 col-xl-6">
                                <h4><?php echo e($p->pname); ?></h4>
                                <div class="d-flex flex-row">
                                    <div class="mb-1 me-2" style="color:#FFD700;">
                                    <i class="fa-solid fa-star"></i>
                                    <i class="fa-solid fa-star"></i>
                                    <i class="fa-solid fa-star"></i>
                                    <i class="fa-solid fa-star"></i>
                                    </div>
                                    <span>(6)</span>
                                </div>

                                <div class="mt-1 mb-0 text-muted small">

                                        <span class="text-primary"> • </span>
                                        <span><?php echo e($p->pcatid); ?></span>

                                </div>

                                <p class="text-truncate mb-4 mb-md-0">
                                    <?php
                                        echo $p->pshort
                                    ?>
                                </p>
                                </div>
                                <div class="col-md-6 col-lg-3 col-xl-3 border-sm-start-none border-start">
                                
                                <div class="d-flex flex-column mt-4">
                                    <a class="btn btn-primary btn-sm" href="<?php echo e(route('product.show', $p->id )); ?>">Details</a>
                                    <a class="btn btn-outline-primary btn-sm mt-2" href="<?php echo e(route('product.edit', $p->id)); ?>">
                                    Update Item
                                    </a>

                                    <form action="<?php echo e(route('product.destroy',$p->id)); ?>" method="post">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="btn btn-danger btn-sm mt-2" style="width: 180px">Delete</button>
                                    </form>
                                </div>
                                </div>
                            </div>
                            </div>
                        </div>
                        </div>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                  </div>

                </div>
              </section>



            
           <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php /**PATH D:\xampp7\htdocs\projects\Laravel-multi-vendor\multivendor\resources\views/seller/viewproduct.blade.php ENDPATH**/ ?>