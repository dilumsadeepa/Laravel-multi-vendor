<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.dashboard','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('dashboard'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>

<h3>create shop</h3>
<?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <strong>Whoops!</strong> There were some problems with your input.<br><br>
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>
    <br>
<form class="forms-sample" action="<?php echo e(route('shop.store')); ?>" enctype="multipart/form-data" method="post">
    <?php echo csrf_field(); ?>
    <div class="form-group">
      <label for="exampleInputName1">Shop Name</label>
      <input type="text" class="form-control" name="title" id="exampleInputName1" placeholder="Name">
    </div>
    <div class="form-group">
      <label for="shopDescription">Shop Description</label>
      <textarea class="form-control" name="shopdis" id="myeditorinstance" rows="4"></textarea>
    </div>
      <div class="form-group">
        <label>Profile Photo</label>
        <input type="file" name="shopprofile" class="file-upload-default" onchange="previewImage1(event);">
        <div class="input-group col-xs-12">
          <input type="text" class="form-control file-upload-info" disabled placeholder="Upload Profile Photo">
          <span class="input-group-append">
            <button class="file-upload-browse btn btn-primary" type="button">Upload</button>
          </span>
        </div>
      </div>


      <div class="form-group">
        <label>Cover Photo</label>
        <input type="file" name="banner" class="file-upload-default" onchange="previewImage2(event);">
        <div class="input-group col-xs-12">
          <input type="text" class="form-control file-upload-info" disabled placeholder="Upload Banner Image">
          <span class="input-group-append">
            <button class="file-upload-browse btn btn-primary" type="button">Upload</button>
          </span>
        </div>
      </div>


      

        <div class="form-group mt-3">
            <label>Shop Category</label>
            <select class="js-example-basic-multiple w-100" name="catagory[]" multiple="multiple">
                <?php $__currentLoopData = $cat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($c->catname); ?>"><?php echo e($c->catname); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
      </div>

    <input type="hidden" name="sellerid" value="<?php echo e(Auth::user()->id); ?>">






    <button type="submit" class="btn btn-primary mr-2">Submit</button>
    <button class="btn btn-light">Cancel</button>
  </form>
  <br><br>
  <div class="row">
    <div class="col-sm-4">
    <div class="preview">
        <img id="preview-selected-image1" class="img-fluid" />
    </div>
    <br>
    <div class="col-sm-4">
        <div class="preview">
            <img id="preview-selected-image2" class="img-fluid" />
        </div>
    </div>
</div>


<style>
    .preview{
        width: 350px;
    }
</style>


<script>
    const previewImage1 = (event) => {

        const imageFiles = event.target.files;

        const imageFilesLength = imageFiles.length;

        if (imageFilesLength > 0) {

            const imageSrc = URL.createObjectURL(imageFiles[0]);

            const imagePreviewElement = document.querySelector("#preview-selected-image1");

            imagePreviewElement.src = imageSrc;

            imagePreviewElement.style.display = "block";
        }
    };

    const previewImage2 = (event) => {

    const imageFiles = event.target.files;

    const imageFilesLength = imageFiles.length;

    if (imageFilesLength > 0) {

        const imageSrc = URL.createObjectURL(imageFiles[0]);

        const imagePreviewElement = document.querySelector("#preview-selected-image2");

        imagePreviewElement.src = imageSrc;

        imagePreviewElement.style.display = "block";
    }
    };

</script>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>

<?php /**PATH D:\xampp7\htdocs\projects\Laravel-multi-vendor\multivendor\resources\views/seller/createshop.blade.php ENDPATH**/ ?>