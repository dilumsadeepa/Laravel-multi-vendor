<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.dashboard','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('dashboard'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>



    <?php if(session('status')): ?>
        <div class="alert alert-success mb-1 mt-1">
            <?php echo e(session('status')); ?>

        </div>
    <?php endif; ?>

    <form action="<?php echo e(route('product.update', $product->id)); ?>" method="post" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <div class="col-12 grid-margin">
            <div class="card">
              <div class="card-body">
                <h4 class="card-title">Edit product</h4>
                <form class="form-sample">
                  <p class="card-description">
                    Product info
                  </p>
                  <div class="row">
                    <div class="col-md-6">
                      <div class="form-group row">
                        <label class="col-sm-3 col-form-label">Product Title</label>
                        <div class="col-sm-9">
                          <input type="text" class="form-control" value="<?php echo e($product->pname); ?>" name="pname">
                        </div>
                      </div>
                    </div>
                    <div class="col-md-6">
                      <div class="form-group row">
                        <label class="col-sm-3 col-form-label">Product Price</label>
                        <div class="col-sm-9">
                          <input type="text" class="form-control" value="<?php echo e($product->pprice); ?>" name="pprice">
                        </div>
                      </div>
                    </div>
                  </div>
                  <div class="row">
                    <div class="col-md-6">
                      <div class="form-group row">
                        <label class="col-sm-3 col-form-label">Select Shop</label>
                        <div class="col-sm-9">
                          <select class="form-control" name="pshopid">
                            <?php $__currentLoopData = $shops; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sh): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($product->pshopid == $sh->id): ?>
                                    <option value="<?php echo e($sh->id); ?>"><?php echo e($sh->title); ?></option>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php $__currentLoopData = $shops; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($s->id); ?>"><?php echo e($s->title); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          </select>
                        </div>
                      </div>
                    </div>
                    <div class="col-md-6">
                      <div class="form-group row">
                        <label class="col-sm-3 col-form-label">Quentity</label>
                        <div class="col-sm-9">
                          <input type="number" class="form-control" placeholder="" value="<?php echo e($product->pqun); ?>" name="pqun"/>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div class="row">
                    <div class="col-md-6">
                      <div class="form-group row">
                        <label class="col-sm-3 col-form-label">Category</label>
                        <div class="col-sm-9">
                          <select class="form-control" name="pcatid">
                            <option value="<?php echo e($product->pcatid); ?>"><?php echo e($product->pcatid); ?></option>
                            <?php $__currentLoopData = $catagory; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($c->catname); ?>"><?php echo e($c->catname); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                          </select>
                        </div>
                      </div>
                    </div>

                    <div class="col-md-6">
                        <div class="form-group row">
                          <label class="col-sm-3 col-form-label">Sub Category</label>
                          <div class="col-sm-9">
                            <input type="text" class="form-control" placeholder="" value="<?php echo e($product->psubcat); ?>" name="psubcat"/>
                          </div>
                        </div>
                      </div>

                  </div>

                  <div class="row">
                    <div class="col-md-6">
                      <div class="form-group row">
                        <label class="col-sm-3 col-form-label">Product</label>
                        <div class="col-sm-4">
                          <div class="form-check">
                            <label class="form-check-label">
                                <?php if($product->dop == "digital"): ?>
                                    <input type="radio" class="form-check-input" id="membershipRadios1" value="digital" name="dop" checked>
                                    Digital
                                <?php else: ?>
                                    <input type="radio" class="form-check-input" id="membershipRadios1" value="digital" name="dop">
                                    Digital
                                <?php endif; ?>
                            </label>
                          </div>
                        </div>
                        <div class="col-sm-5">
                          <div class="form-check">
                            <label class="form-check-label">
                                <?php if($product->dop == "physical"): ?>
                                    <input type="radio" class="form-check-input" id="membershipRadios2" value="physical" name="dop" checked>
                                    Physical product
                                <?php else: ?>
                                    <input type="radio" class="form-check-input" id="membershipRadios2" value="physical" name="dop">
                                    Physical product
                                <?php endif; ?>
                            </label>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <p class="card-description">
                    info
                  </p>
                  <div class="row">
                    <div class="col-md-6">
                      <div class="form-group row">
                        <label class="col-sm-3 col-form-label">Product Image</label>
                        <div class="col-sm-9">
                            <div class="form-group">
                                <div class="form-group">

                                    <input type="hidden" id="pimg" name="pimg" value="<?php echo e($product->pimg); ?>">

                                    
                                  </div>
                            </div>
                        </div>
                      </div>
                    </div>
                    <div class="col-md-6">
                        <div class="preview">
                            <img id="preview-selected-image" class="img-fluid" />
                        </div>
                    </div>
                    <div class="row" id="row">

                    </div>

                  <div class="row">
                    <div class="col-md-12">
                      <div class="form-group row">
                        <label class="col-sm-3 col-form-label">Discription</label>
                        <div class="col-sm-9">
                            <textarea id="myeditorinstance" name="pdis"><?php echo e($product->pdis); ?></textarea>
                        </div>
                      </div>
                    </div>
                    <div class="col-md-12">
                        <div class="form-group row">
                            <label class="col-sm-3 col-form-label">Short Discription</label>
                            <div class="col-sm-9">
                                <textarea id="myeditorinstance" name="pshort"><?php echo e($product->pshort); ?></textarea>
                            </div>
                          </div>
                    </div>
                  </div>

                  <button type="submit" class="btn btn-primary mr-2">Submit</button>
                  <button class="btn btn-light">Cancel</button>

                </form>
              </div>
            </div>
          </div>

        </form>


<style>
    .preview{
        width: 350px;
    }
</style>


<script>

    const previewImage = (event) => {

        const imageFiles = event.target.files;

        const imageFilesLength = imageFiles.length;

        if (imageFilesLength > 0) {

            const imageSrc = URL.createObjectURL(imageFiles[0]);

            const imagePreviewElement = document.querySelector("#preview-selected-image");

            imagePreviewElement.src = imageSrc;

            imagePreviewElement.style.display = "block";
        }
    };
</script>


 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php /**PATH D:\xampp7\htdocs\projects\Laravel-multi-vendor\multivendor\resources\views/seller/editproduct.blade.php ENDPATH**/ ?>