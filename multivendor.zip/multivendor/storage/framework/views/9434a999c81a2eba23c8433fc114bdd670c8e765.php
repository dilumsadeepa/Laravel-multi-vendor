<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.dashboard','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('dashboard'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
   <div class="container py-2">
      <div class="row">
         <div class="col">
            <button type="button" class="btn btn-secondary m-3">Back</button>
         </div>
      </div>
      <div class="row">
         <div class="col-lg-4">
            <div class="card mb-4">
               <div class="card-body text-center">
                  <img src="https://mdbcdn.b-cdn.net/img/Photos/new-templates/bootstrap-chat/ava3.webp" alt="avatar"
                     class="rounded-circle img-fluid" style="width: 150px;">
                  <h5 class="my-3">User name</h5>
                  <div class="d-flex justify-content-center mb-2">
                     
                     
                  </div>
                  <hr>
                  
                  <div class="col-12 grid-margin stretch-card">
                     <div class="card">
                        <div class="card-body">
                           <h4 class="card-title">Tracking Number</h4>
                           <p class="card-description">
                              Add tracking number
                           </p>
                           <form class="form-inline">
                              <label class="sr-only" for="inlineFormInputName2">Name</label>
                              <input type="text" class="form-control mb-2 mr-sm-2" id="inlineFormInputName2" placeholder="Tracking . . . .">
                              <button type="submit" class="btn btn-primary mb-2 ml-5">Submit</button>
                           </form>
                        </div>
                     </div>
                  </div>
                  
               </div>
            </div>
         </div>
         <!-- Getting backend data -->
         <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
         <div class="col-lg-8">
            <div class="card mb-4">
               <div class="card-body">
                  <div class="row">
                     <div class="col-md-12 grid-margin stretch-card">
                        <div class="card tale-bg">
                           <div class="card-people mt-auto">
                              <img src="<?php echo e(asset('uploads/'.$order->pimg)); ?>" alt="people" style="max-height: 310px">
                              <div class="weather-info">
                                 <div class="d-flex">
                                    <div>
                                       
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
                  <div class="row">
                     <div class="col-sm-3">
                        <p class="mb-0">Full Name</p>
                     </div>
                     <div class="col-sm-9">
                        <p class="text-muted mb-0"><?php echo e($order->name); ?>&nbsp<?php echo e($order->lastname); ?></p>
                     </div>
                  </div>
                  <hr>
                  <div class="row">
                     <div class="col-sm-3">
                        <p class="mb-0">Email</p>
                     </div>
                     <div class="col-sm-9">
                        <p class="text-muted mb-0"><?php echo e($order->email); ?></p>
                     </div>
                  </div>
                  <hr>
                  <div class="row">
                     <div class="col-sm-3">
                        <p class="mb-0">Phone</p>
                     </div>
                     <div class="col-sm-9">
                        <p class="text-muted mb-0"><?php echo e($order->tel); ?></p>
                     </div>
                  </div>
                  <hr>
                  <hr>
                  <div class="row">
                     <div class="col-sm-3">
                        <p class="mb-0">Address</p>
                     </div>
                     <div class="col-sm-9">
                        <p class="text-muted mb-0"><?php echo e($order->addressl1); ?><br><?php echo e($order->addressl2); ?><br><?php echo e($order->addressl3); ?></p>
                     </div>
                  </div>
                  <hr>
                  <hr>
                  <div class="row">
                     <div class="col-sm-3">
                        <p class="mb-0">Item Name</p>
                     </div>
                     <div class="col-sm-9">
                        <p class="text-muted mb-0"><?php echo e($order->pname); ?></p>
                     </div>
                  </div>
                  <hr>
                  <hr>
                  <div class="row">
                     <div class="col-sm-3">
                        <p class="mb-0">Quantity</p>
                     </div>
                     <div class="col-sm-9">
                        <p class="text-muted mb-0"><?php echo e($order->oqun); ?></p>
                     </div>
                  </div>
                  <hr>
                  <hr>
                  <div class="row">
                     <div class="col-sm-3">
                        <p class="mb-0">Total price</p>
                     </div>
                     <div class="col-sm-9">
                        <!-- Currency should be set in here -->
                        <p class="text-muted mb-0"><?php echo e(number_format($order->oqun*$order->oprice, 2)); ?></p>
                     </div>
                  </div>
                  <hr>
                  <hr>
                  <div class="row">
                     <div class="col-sm-3">
                        <p class="mb-0">Order Date</p>
                     </div>
                     <div class="col-sm-9">
                        <p class="text-muted mb-0"><?php echo e($order->created_at); ?></p>
                     </div>
                  </div>
                  <hr>
                  <div class="row">
                     <div class="col-sm-3">
                        <p class="mb-0">Payment Status</p>
                     </div>
                     <div class="col-sm-9">
                        <p class="text-muted mb-0"><?php echo e($order->paymentstatus); ?></p>
                     </div>
                  </div>
                  <hr>
               </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <!-- End of getting backend data -->
         </div>
      </div>
   </div>
   </div>
   </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?><?php /**PATH /home2/encodeco/public_html/multivendor/resources/views/seller/orderdetail.blade.php ENDPATH**/ ?>