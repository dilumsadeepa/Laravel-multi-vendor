<div class="hidden sm:block">
    <div class="py-8">
        <div class="border-t border-gray-200"></div>
    </div>
</div>
<?php /**PATH /home2/encodeco/public_html/multivendor/resources/views/vendor/jetstream/components/section-border.blade.php ENDPATH**/ ?>