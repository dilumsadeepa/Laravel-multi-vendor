<?php
   use Carbon\Carbon;
   $date = Carbon::now()->format('Y-m-d');
   $time = Carbon::now()->format('H:i:s');
   ?>
<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.dashboard','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('dashboard'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <style>
.swiper {
      width: 100%;
      height: 100%;
    }

    .swiper-slide {
      text-align: center;
      font-size: 18px;
      background: #fff;
      display: flex;
      justify-content: center;
      align-items: center;
    }

    .swiper-slide img {
      display: block;
      width: 100%;
      height: 100%;
      object-fit: cover;
      border-radius: 0px !important;
    }

    </style>


   <div class="row">
      <div class="col-md-12 grid-margin">
         <div class="row">
            <div class="col-12 col-xl-8 mb-4 mb-xl-0">
               <?php if(auth()->guard()->check()): ?>
               <h3 class="font-weight-bold">Welcome <?php echo e(auth()->user()->name); ?></h3>
               <?php endif; ?>
            </div>
         </div>
      </div>
   </div>
   <div class="row">
      <div class="col-md-6 grid-margin stretch-card">
         <div class="card tale-bg">
            <div class="card-people" style="padding-top: 0; border-radius: 30px;">

                


                  <div class="swiper mySwiper">
                    <div class="swiper-wrapper">
                    <div class="swiper-slide"><img src="images/carousel/banner_1.jpg" alt="people" style="max-height: 310px"></div>
                    <div class="swiper-slide"><img src="images/carousel/banner_2.jpg" alt="people" style="max-height: 310px"></div>
                    <div class="swiper-slide"><img src="images/carousel/banner_3.jpg" alt="people" style="max-height: 310px"></div>
                    <div class="swiper-slide"><img src="images/carousel/banner_4.jpg" alt="people" style="max-height: 310px"></div>
                    <div class="swiper-slide"><img src="images/carousel/banner_5.jpg" alt="people" style="max-height: 310px"></div>
                    <div class="swiper-slide"><img src="images/carousel/banner_6.jpg" alt="people" style="max-height: 310px"></div>
                    <div class="swiper-slide"><img src="images/carousel/banner_7.jpg" alt="people" style="max-height: 310px"></div>
                    <div class="swiper-slide"><img src="images/carousel/banner_8.jpg" alt="people" style="max-height: 310px"></div>
                    </div>

                    <div class="swiper-pagination"></div>
                    </div>



               
               <div class="weather-info">
                  <div class="d-flex">
                     <div>
                        
                     </div>
                     <div class="ml-2">
                        <h4 class="location font-weight-normal"><?php echo e($date); ?></h4>
                        <h6 class="font-weight-normal"><?php echo e($time); ?></h6>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </div>
      <div class="col-md-6 grid-margin transparent">
         <div class="row">
            <div class="col-md-6 mb-4 stretch-card transparent">
               <div class="card card-tale">
                  <div class="card-body">
                     <p class="mb-4">Today’s Orders</p>
                     <p class="fs-30 mb-2"><?php echo e($TodayOrderCount); ?></p>
                     <p>10.00% (30 days)</p>
                  </div>
               </div>
            </div>
            <div class="col-md-6 mb-4 stretch-card transparent">
               <div class="card card-dark-blue">
                  <div class="card-body">
                     <p class="mb-4">This month Orders</p>
                     <p class="fs-30 mb-2"><?php echo e($MonthOrderCount); ?></p>
                     <p>22.00% (30 days)</p>
                  </div>
               </div>
            </div>
         </div>
         <div class="row">
            <div class="col-md-6 mb-4 mb-lg-0 stretch-card transparent">
               <div class="card card-light-blue">
                  <div class="card-body">
                     <p class="mb-4">All Orders</p>
                     <p class="fs-30 mb-2"><?php echo e($AllOrderCount); ?></p>
                     <p>2.00% (30 days)</p>
                  </div>
               </div>
            </div>
            <div class="col-md-6 stretch-card transparent">
               <div class="card card-light-danger">
                  <div class="card-body">
                     <p class="mb-4">Toatl Revenue</p>
                     <p class="fs-30 mb-2">$ <?php echo e($revenuetotal); ?></p>
                     <p>0.22% (30 days)</p>
                  </div>
               </div>
            </div>
         </div>
      </div>
   </div>
   <div class="col-lg-12 grid-margin stretch-card">
      <div class="card">
         <div class="card-body">
            <h4 class="card-title">Orders</h4>
            <p class="card-description">
               All <code>.Orders</code>
            </p>
            <div class="table-responsive">
               <table class="table table-striped">
                  <thead>
                     <tr>
                        <th>
                           User
                        </th>
                        <th>
                           User name
                        </th>
                        <th>
                           Payment Status
                        </th>
                        <th>
                           Amount
                        </th>
                        <th>
                           Order Date
                        </th>
                        <th>
                           Action
                        </th>
                     </tr>
                  </thead>
                  <tbody>
                     <tr>
                        <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <td class="py-1">
                           <!-- User image is not set and can't set the image right now -->
                           <img src="<?php echo e(asset('images/faces/face1.jpg')); ?>" alt="image"/>
                        </td>
                        <td>
                           <?php echo e($order->name); ?>

                        </td>
                        <td>
                           <?php echo e($order->paymentstatus); ?>

                        </td>
                        <td>
                           <!-- Currency should be set in here -->
                           $<?php echo e(number_format($order->oqun*$order->oprice, 2)); ?>

                        </td>
                        <td>
                           <?php echo e($order->created_at); ?>

                        </td>
                        <td>
                           <button type="button" class="btn btn-success btn-icon-text">

                           <a href="<?php echo e(route('order.show', $order->orderid )); ?>" style="text-decoration: none;">
                            <i class="ti-file btn-icon-append"></i>  View</a>
                           </button>
                        </td>
                     </tr>
                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </tbody>
               </table>
            </div>
         </div>
      </div>
   </div>
   </div>
   </div>

   <script src="https://cdn.jsdelivr.net/npm/swiper@9/swiper-bundle.min.js"></script>
  <script>
    var swiper = new Swiper(".mySwiper", {
      spaceBetween: 30,
      centeredSlides: true,
      autoplay: {
        delay: 60000,
        disableOnInteraction: false,
      },
      pagination: {
        el: ".swiper-pagination",
        clickable: true,
      },
      navigation: {
        nextEl: ".swiper-button-next",
        prevEl: ".swiper-button-prev",
      },
    });
  </script>



 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php /**PATH /home2/encodeco/public_html/multivendor/resources/views/seller/index.blade.php ENDPATH**/ ?>