<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.dashboard','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('dashboard'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
   <div class="col-lg-12 grid-margin stretch-card">
      <div class="card">
         <div class="card-body">
            <h4 class="card-title">Orders</h4>
            <p class="card-description">
               All <code>.Orders</code>
            </p>
            <div class="table-responsive">
               <table class="table table-striped">
                  <thead>
                     <tr>
                        <th>
                           User
                        </th>
                        <th>
                           User name
                        </th>
                        <th>
                           Payment Status
                        </th>
                        <th>
                           Amount
                        </th>
                        <th>
                           Order Date
                        </th>
                        <th>
                           Action
                        </th>
                     </tr>
                  </thead>
                  <tbody>
                     <tr>
                        <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <td class="py-1">
                           <!-- User image is not set and can't set the image right now -->
                           <img src="../../images/faces/face1.jpg" alt="image"/>
                        </td>
                        <td>
                           <?php echo e($order->firstname); ?>

                        </td>
                        <td>
                           <?php echo e($order->paymentstatus); ?>  
                        </td>
                        <td>
                           <!-- Currency should be set in here -->
                           <?php echo e(number_format($order->oqun*$order->oprice, 2)); ?>

                        </td>
                        <td>
                           <?php echo e($order->created_at); ?>  
                        </td>
                        <td>
                           <button type="button" class="btn btn-success btn-icon-text">
                                                                              
                           <a href="<?php echo e(route('order.show', $order->id )); ?>" style="text-decoration: none;">
                            <i class="ti-file btn-icon-append"></i> View</a>
                           </button>
                        </td>
                     </tr>
                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </tbody>
               </table>
            </div>
         </div>
      </div>
   </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?><?php /**PATH /Users/warunapradeep/Documents/Laravel-multi-vendor/multivendor/resources/views/seller/vieworders.blade.php ENDPATH**/ ?>